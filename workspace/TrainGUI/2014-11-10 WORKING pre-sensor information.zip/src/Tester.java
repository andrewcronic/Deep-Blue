
public class Tester {
	
	public static void main (String[] Args)
	{
		new ServerInterface();
		//new ClientInterface();
		new SerialTest();
		ClientInterface.main(Args);
		
	}

}

