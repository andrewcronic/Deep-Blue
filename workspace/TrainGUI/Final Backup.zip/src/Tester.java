
public class Tester {
	
	public static void main (String[] Args)
	{
		new ServerInterface();
	
		new ClientInterface("localhost");
		
		new SerialTest();
		
		ClientInterface.main(Args);
		
	}

}

