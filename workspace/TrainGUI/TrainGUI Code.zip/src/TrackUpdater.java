import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class TrackUpdater extends Thread
{
	static ImageIcon imgIcon = new ImageIcon();
	static ImageIcon[] imageArray = new ImageIcon[14];
	static int threadDelay = 1000;
	static boolean stopped = true;
	static ImageIcon currentImage = new ImageIcon("1.jpg"); //sets initial screen to 1.jpg
	static int currentImageNumber = 0;
	static int currentSpeed = 0;
	
	public void run()
	{
		System.out.println("RUNNING");

		try {
			
			//Read in all picture files and store in ImageArray
			for(int i = 0; i < imageArray.length; i++)
			{
				
				String fileNum = (i + 1) + ".jpg";
				
				BufferedImage tempImage = ImageIO.read(new File(fileNum));
				imageArray[i] = new ImageIcon(tempImage);
			}
		} 
		
		catch (IOException e) {
		}

		//ClientInterface.setImageLabel(imageArray[0]); //sets initial screen

		
		while(true)
		{
			
			
				if(currentSpeed > 0)
				{
					
					if(currentImageNumber > imageArray.length - 1)
					{
						setCurrentImageNumber(0);
					}
					
					
					if(currentImageNumber < 0)
					{
						setCurrentImageNumber(imageArray.length - 1);
					}
						
						ClientInterface.setImageLabel(imageArray[currentImageNumber]);
						setCurrentImage(imageArray[currentImageNumber]);
						setCurrentImageNumber(currentImageNumber + 1);
						
						try 
						{
							Thread.sleep(threadDelay);
						} 
						
						catch (InterruptedException e) 
						{
						
							e.printStackTrace();
						}
		
				}
				
				if(currentSpeed < 0)
				{
					
					if(currentImageNumber > imageArray.length - 1)
					{
						setCurrentImageNumber(0);
					}
					
					
					if(currentImageNumber < 0)
					{
						setCurrentImageNumber(imageArray.length - 1);
					}

						
						ClientInterface.setImageLabel(imageArray[currentImageNumber]);
						setCurrentImage(imageArray[currentImageNumber]);
						setCurrentImageNumber(currentImageNumber - 1);
						
						try 
						{
							Thread.sleep(threadDelay);
						} 
						
						catch (InterruptedException e) 
						{
						
							e.printStackTrace();
						}
		
				}
				
				if(currentSpeed == 0)
				{
					ClientInterface.setImageLabel(currentImage);
				}
			
	
		} //END WHILE TRUE
	
	
			
			
		
	} //END RUN
	
	public static void setThreadDelay(int delayNum)
	{
		threadDelay = delayNum;
	}
	
	public static void setCurrentSpeed(int trainSpeed)
	{
		currentSpeed = trainSpeed;
	}
	
	public static void setCurrentImageNumber(int imgNum)
	{
		
		currentImageNumber = imgNum;
	}
	
	public static void setStopped(boolean isStopped)
	{
		stopped = isStopped;
	}
	
	public static void setCurrentImage(ImageIcon currentImg)
	{
		currentImage = currentImg;
	}
}