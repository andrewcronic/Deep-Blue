import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class ClientInterface 
{
	private static int trainID = 1;
	private JFrame frame = new JFrame("Train Client Interface - Train " + trainID);
	private JPanel trackPanel = new JPanel();
	private JPanel sliderPanel = new JPanel();
	private JPanel statusPanel = new JPanel();
	private JPanel buttonPanel = new JPanel();
	private JPanel northPanel = new JPanel();
	private JLabel trainIDLabel = new JLabel("   Train ID: " + trainID + "   ");

	private JButton hornButton = new JButton("HORN");
	private JButton lightButton = new JButton("LIGHTS");
	private JButton quickStopButton = new JButton("QUICK STOP");
	private JMenuBar menu = new JMenuBar();
	private JMenu file = new JMenu("File");
	private JMenu help = new JMenu("Help");
	private JMenuItem quit = new JMenuItem("Quit");
	private JMenuItem about = new JMenuItem("About Program");
	private static JLabel speedPic = new JLabel();
	private static JLabel directionPic = new JLabel();
	private static JLabel imageLabel = new JLabel();
	private static JLabel speedLabel = new JLabel("       SPEED: ");
	private static JLabel directionLabel = new JLabel("   DIRECTION: ");
	BufferedImage speedImg = null;
	BufferedImage dirImg = null;
	private static ImageIcon[] speedArray = new ImageIcon[4];
	private static ImageIcon[] directionArray = new ImageIcon[3];
	static final int sliderMin = -3;
	static final int sliderMax = 3;
	static final int sliderInitial = 0;    //initial slider setting (STOP)
	static JSlider speedSlider = new JSlider(JSlider.VERTICAL, sliderMin, sliderMax, sliderInitial);
	
	public ClientInterface()
	{
		
		frame.setBackground(Color.blue);
		frame.setSize(1000,700);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);

		//Turn on labels at major tick marks.
		speedSlider.setMajorTickSpacing(1);
		speedSlider.setMinorTickSpacing(1);
		speedSlider.setPaintTicks(true);
		speedSlider.setPaintLabels(true);

		//ADD BUTTONS FOR HORN AND LIGHTS
		
		trackPanel.setLayout(new GridBagLayout());
		trackPanel.setBackground(Color.gray);
		sliderPanel.setLayout(new BorderLayout());
		sliderPanel.setBackground(Color.LIGHT_GRAY);
		statusPanel.setLayout(new GridLayout(0,2,0,0));
		statusPanel.setBackground(Color.LIGHT_GRAY);
		northPanel.setBackground(Color.LIGHT_GRAY);
		northPanel.setLayout(new BorderLayout());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setBackground(Color.LIGHT_GRAY);
		hornButton.setBackground(Color.green);
		lightButton.setBackground(Color.yellow);
		quickStopButton.setBackground(Color.red);
		speedSlider.setBackground(Color.white);
		speedSlider.addChangeListener(new SliderListener());
		
		quit.setVisible(true);
		help.setVisible(true);
		file.setVisible(true);
		menu.setVisible(true);
		about.setVisible(true);
		menu.add(file);
		menu.add(help);
		file.add(quit);
		help.add(about);
		
		trainIDLabel.setFont(new Font("Serif", Font.BOLD, 24));
		buttonPanel.add(trainIDLabel);
		hornButton.setIcon(new ImageIcon("horn.jpg"));
		buttonPanel.add(hornButton);
		lightButton.setIcon(new ImageIcon("lights.jpg"));
		buttonPanel.add(lightButton);
		quickStopButton.setIcon(new ImageIcon("stop.jpg"));
		buttonPanel.add(quickStopButton);
		northPanel.add(menu, BorderLayout.NORTH);
		northPanel.add(buttonPanel, BorderLayout.SOUTH);
		imageLabel.setIcon(new ImageIcon("1.jpg"));
		trackPanel.add(imageLabel);
		speedLabel.setFont(new Font("Serif", Font.BOLD, 20));
		directionLabel.setFont(new Font("Serif", Font.BOLD, 20));
		statusPanel.add(speedLabel);
		statusPanel.add(directionLabel);
		statusPanel.add(speedPic); // NEED TO MAKE PART OF JLABEL
		statusPanel.add(directionPic);
		JLabel colorScale = new JLabel();
		colorScale.setIcon(new ImageIcon("colorscale.jpg"));
		sliderPanel.add(new JLabel("FORWARD"), BorderLayout.NORTH);
		sliderPanel.add(colorScale, BorderLayout.CENTER);
		sliderPanel.add(speedSlider, BorderLayout.EAST);
		sliderPanel.add(new JLabel("REVERSE"), BorderLayout.SOUTH);
		sliderPanel.add(new JLabel("STOP"), BorderLayout.WEST);
		frame.add(northPanel, BorderLayout.NORTH);
		frame.add(trackPanel, BorderLayout.CENTER);
		frame.add(sliderPanel, BorderLayout.EAST);
		frame.add(statusPanel, BorderLayout.SOUTH);
		northPanel.setVisible(true);
		buttonPanel.setVisible(true);
		statusPanel.setVisible(true);
		sliderPanel.setVisible(true);
		trackPanel.setVisible(true);
		frame.setVisible(true);
		
		quit.addActionListener(new ActionListener() {
	       	 
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }); 
		
		about.addActionListener(new ActionListener() {
	       	 
            public void actionPerformed(ActionEvent e)
            {
                JFrame aboutFrame = new JFrame("User / System Documentation");
                JTextArea aboutArea = new JTextArea("HOW TO USE PROGRAM: " +'\n'
                		+ "Use the slider on the right side of the frame to control the speed of the train." + '\n' + '\n'
                		+ "SPEEDS:" + '\n' + "------------------------------" + '\n'
                		+ "3 - Forward, High Speed" + '\n'
                		+ "2 - Forward, Medium Speed" + '\n'
                		+ "1 - Forward, Low Speed" + '\n'
                		+ "0 - STOPPED, Not Moving" + '\n'
                		+ "-1 - Reverse, Low Speed" + '\n'
                		+ "-2 - Reverse, Medium Speed" + '\n'
                		+ "-3 - Reverse, High Speed" + '\n' + '\n'
                		+ "Click the Green Horn Button to sound the trains horn." + '\n'
                		+ "Click the Yellow Lights button to enable the trains lights");
                aboutArea.setEditable(false);
                aboutFrame.setSize(450, 300);
                aboutFrame.setLocationRelativeTo(null);
                aboutFrame.add(aboutArea);
                aboutFrame.setVisible(true);
            }
        }); 
		
		hornButton.addActionListener(new ActionListener() {
	       	 
            public void actionPerformed(ActionEvent e)
            {
                System.out.println("HORN PRESSED");
            }
        }); 
		
		lightButton.addActionListener(new ActionListener() {
	       	 
            public void actionPerformed(ActionEvent e)
            {
                System.out.println("LIGHTS PRESSED");
            }
        }); 
		
		quickStopButton.addActionListener(new ActionListener() {
	       	 
            public void actionPerformed(ActionEvent e)
            {
                System.out.println("QUICK STOP BUTTON");
                speedSlider.setValue(0);
                TrackUpdater.setCurrentSpeed(0);
                TrackUpdater.setStopped(true);
                setSpeedPic(0);
	            setDirectionPic(0);
	            
            }
        }); 
		
		
		}
		
		
	class SliderListener implements ChangeListener {
	    public void stateChanged(ChangeEvent e) {
	    	
	        JSlider source = (JSlider)e.getSource();
	        
	        if (!source.getValueIsAdjusting()) 
	        {
	            int speedValue = (int)source.getValue();
	            System.out.println("SPEED UPDATED: " + speedValue);
	            
	            
	            if(!(speedValue == 0))
	            {
	            	TrackUpdater.setStopped(false);
	            }
	            
	            if(speedValue == 0)
		        {
		            TrackUpdater.setStopped(true);
		            TrackUpdater.setCurrentSpeed(0);
		            setSpeedPic(0);
		            setDirectionPic(0);
		        }
	            
	            if(speedValue == 3)
	            {
	            	TrackUpdater.setThreadDelay(300);
	            	TrackUpdater.setCurrentSpeed(3);
	            	setSpeedPic(3);
			        setDirectionPic(1);
	            }
	            
	            if(speedValue == 2)
	            {
	            	TrackUpdater.setThreadDelay(500);
	            	TrackUpdater.setCurrentSpeed(2);
	            	setSpeedPic(2);
			        setDirectionPic(1);
	            }
	            
	            if(speedValue == 1)
	            {
	            	TrackUpdater.setThreadDelay(1000);
	            	TrackUpdater.setCurrentSpeed(1);
	            	setSpeedPic(1);
			        setDirectionPic(1);
	            }
	            
	            if(speedValue == -3)
	            {
	            	TrackUpdater.setThreadDelay(300);
	            	TrackUpdater.setCurrentSpeed(-3);
	            	setSpeedPic(3);
			        setDirectionPic(2);
	            }
	            
	            if(speedValue == -2)
	            {
	            	TrackUpdater.setThreadDelay(500);
	            	TrackUpdater.setCurrentSpeed(-2);
	            	setSpeedPic(2);
			        setDirectionPic(2);
	            }
	            
	            if(speedValue == -1)
	            {
	            	TrackUpdater.setThreadDelay(1000);
	            	TrackUpdater.setCurrentSpeed(-1);
	            	setSpeedPic(1);
			        setDirectionPic(2);
	            }
            
	        }    
	    }
	}
	

	
	public static void main(String Args[])
	{

		new ClientInterface();

		try {
			
			for(int i = 0; i < speedArray.length; i++)
			{
				String speedNum = "speed" + (i) + ".jpg";
				ImageIcon tempSpeed = new ImageIcon(ImageIO.read(new File(speedNum)));
				speedArray[i] = tempSpeed;
				
			}
			
			for(int i = 0; i < directionArray.length; i++)
			{
				String directionNum = "direction" + (i) + ".jpg";
				ImageIcon tempDir = new ImageIcon(ImageIO.read(new File(directionNum)));
				directionArray[i] = tempDir;
				
			}
			
		} 
		
		catch (IOException e) {
		}
		
		speedPic.setIcon(speedArray[0]);
		directionPic.setIcon(directionArray[0]);
		
		TrackUpdater t = new TrackUpdater();
		t.start();

	}
	
	public static void setImageLabel(ImageIcon imageNumber)
	{
		imageLabel.setIcon(imageNumber);
	}
	
	public static void setSpeedPic(int speedNumber)
	{
		speedPic.setIcon(speedArray[speedNumber]);
	}
	
	public static void setDirectionPic(int dirNumber)
	{
		directionPic.setIcon(directionArray[dirNumber]);
	}


}




