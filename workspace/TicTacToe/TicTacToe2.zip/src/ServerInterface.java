import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;



public class ServerInterface {
	
	static JPanel sessionPanel = new JPanel();
	JLabel inputLabel = new JLabel("null");
	JMenuBar menubar = new JMenuBar();
	JPanel serverPanel = new JPanel();
	JMenu file = new JMenu("File");
	JMenuItem quit = new JMenuItem("Quit");
	
	public ServerInterface()
	{
		JFrame frame = new JFrame("Server Side Interface");
    	frame.setSize(400,400);
    	frame.setResizable(true);
    	frame.setLocationRelativeTo(null);
    	serverPanel.setLayout(new BorderLayout());
    	sessionPanel.setLayout(new BoxLayout(sessionPanel, BoxLayout.Y_AXIS));
    
 
    	file.add(quit);
    	menubar.add(file);
    	serverPanel.add(menubar, BorderLayout.NORTH);
    	serverPanel.add(sessionPanel, BorderLayout.CENTER);
    	serverPanel.add(inputLabel, BorderLayout.SOUTH);
    	sessionPanel.setVisible(true);
    	frame.add(serverPanel);
    	frame.setVisible(true);
    	
        quit.addActionListener(new ActionListener() {
       	 
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }); 
	}
	
	public void addSessionButton(String sessionID)
	{
		String id = sessionID;
		JButton tempButton = new JButton(sessionID);
		tempButton.setVisible(true);
		sessionPanel.add(tempButton);
		sessionPanel.repaint();
		sessionPanel.setVisible(true);

		
		
		   tempButton.addActionListener(new ActionListener() {
		       	 
	            public void actionPerformed(ActionEvent e)
	            {
	                JFrame gameFrame = new JFrame("Game Session Window");
	                gameFrame.setSize(320,320);
	                JPanel gamePanel = new JPanel();
	                JPanel boardPanel = new JPanel();                
	                
	                boardPanel.setBackground(Color.black);
	                boardPanel.setLayout(new GridLayout(3, 3, 2, 2));
	                for (int i = 0; i < board.length; i++) 
	                {
	                    final int j = i;
	                    board[i] = new Square();
	                    boardPanel.add(board[i]);
	                }
	                gameFrame.getContentPane().add(boardPanel, "Center");
	                gameFrame.setVisible(true);                
	                
	            }
	        }); 
		
	}
	
	 static Square[] board = new Square[9];
	
	static class Square extends JPanel {
        JLabel label = new JLabel((Icon)null);

        public Square() {
            setBackground(Color.white);
            add(label);
        }

        public void setIcon(Icon icon) {
            label.setIcon(icon);
        }
    }

}
